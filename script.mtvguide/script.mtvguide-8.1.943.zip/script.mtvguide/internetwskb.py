#      Copyright (C) 2018 Mariusz Brychcy
#      Some implementation are modificated and taken from "plugin.video.internetws" - thank you very much mbebe!

import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import urllib
from strings import *

DATA_PATH      = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
windowDialog   = xbmcgui.WindowDialog()

def Keyboard(response):
    try:
        image = os.path.join(DATA_PATH,'captcha')
        f = xbmcvfs.File(image, 'w')
        f.write(response)
        f.close()
        f = xbmcgui.ControlImage(385, 255, 510, 90, image)

        d = windowDialog
        d.addControl(f)
        xbmcvfs.delete(image)
        d.show()

        kb = xbmc.Keyboard('','')
        kb.setHeading(strings(30009).encode('utf-8', 'replace'))
        kb.setHiddenInput(False)
        kb.doModal()
        c = kb.getText() if kb.isConfirmed() else None
        if c == '': c = None
        d.removeControl(f)
        d.close()
        return c.upper()

    except:
        return

def getDialog(title='',text='',action=''):
    xbmcgui.Dialog().ok(title,text,action)