#      Copyright (C) 2018 Mariusz Brychcy
#      Copyright (C) 2016 Andrzej Mleczko

import os, copy
import xbmc
from strings import *
from serviceLib import *
from random import randrange
import requests

serviceName         = 'WP Pilot'
videostarUrl        = 'https://pilot.wp.pl/api/'
COOKIE_FILE         = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')) , 'videostar.cookie')
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': 'https://pilot.wp.pl/tv',
    'Connection': 'keep-alive',
    'TE': 'Trailers',
}

class VideoStarUpdater(baseServiceUpdater):
    def __init__(self):
        self.serviceName        = serviceName
        self.localMapFile       = 'videostarmap.xml'
        baseServiceUpdater.__init__(self)
        self.serviceEnabled     = ADDON.getSetting('videostar_enabled')
        self.login              = ADDON.getSetting('videostar_username').strip()
        self.password           = ADDON.getSetting('videostar_password').strip()
        self.servicePriority    = int(ADDON.getSetting('priority_videostar'))
        self.url                = videostarUrl
        self.addDuplicatesToList = True
        self.cookie             = None
        self.cookie_postfix     = None

    def cookiesToString(self, cookies):
        try:
            return "; ".join([str(x) + "=" + str(y) for x, y in cookies.get_dict().items()])
        except Exception as e:
            self.log('Exception while trying to convert cookies: %s' % getExceptionString())
            return ''

    def loginService(self):
        try:
            data = {'device': 'android', 'login': self.login, 'password': self.password}
            response = requests.post(
                self.url + 'v1/user_auth/login',
                json=data,
                verify=False,
                headers=headers
            )

            meta = response.json().get('_meta', None)
            if meta is not None:
                if meta.get('error', {}).get('name', None) is not None:
                    self.log('Error when trying to login in videostar!, result: %s' % str(response.json()))
                    self.loginErrorMessage()
                    return False

            cookie = self.cookiesToString(response.cookies)
            headers.update({'Cookie': cookie})
            self.cookie_postfix = "|Cookie=" + cookie + "&User-Agent=" + headers['User-Agent']
            
            return True

            #params = {}
            #params['login'] = self.login
            #params['password'] = self.password
            #params['device'] = 'android'

            #data = self.sl.getJsonFromExtendedAPI(self.url + 'v1/user_auth/login', post_data=params, save_cookie=True, cookieFile=COOKIE_FILE, jsonLoadsResult=True, json_dumps_post=True, skipSslCertificate=True, customHeaders=headers)
            #if data is None or data['data'] is None:
                #self.log('Error when trying to login in videostar!, result: %s' % str(data))
                #self.loginErrorMessage()
                #return False
            #else:
                #self.log('Logged in, data: %s' % str(data))
                #userdata = data['user']
                #return True
        except:
            self.log('Exception while trying to log in: %s' % getExceptionString())
            self.loginErrorMessage()
        return False

    def getChannelList(self, silent):
        result = list()
        if not self.loginService():
            return result

        self.log('\n\n')
        self.log('[UPD] Pobieram liste dostepnych kanalow %s z %s' % (self.serviceName, self.url))
        self.log('[UPD] -------------------------------------------------------------------------------------')
        self.log('[UPD] %-10s %-35s %-15s %-20s %-35s' % ( '-CID-', '-NAME-', '-GEOBLOCK-', '-ACCESS STATUS-', '-IMG-'))

        try:
            httpdata = requests.get(self.url + '/channels/list/android-plus', verify=False, headers=headers).json()
            #httpdata = self.sl.getJsonFromExtendedAPI(self.url + '/channels/list/android-plus', cookieFile = COOKIE_FILE, load_cookie = True, jsonLoadsResult=True, skipSslCertificate=True, customHeaders=headers)
            if httpdata is None or httpdata['status'] != 'ok':
                self.log('Error while trying to get channel list, result: %s' % str(httpdata))
                self.noPremiumMessage()
                return result

            channels = httpdata['channels']
            for channel in channels:
                #self.log('Channel %s' % channel)
                name = channel['name']
                cid  = channel['id']
                img  = channel['thumbnail']
                geoblocked = channel['geoblocked']
                access = channel['access_status']
                self.log('[UPD] %-10s %-35s %-15s %-20s %-35s' % (cid, name, geoblocked, access, img))
                if geoblocked != True and access != 'unsubscribed':
                    program = TvCid(cid, name, name, img=img)
                    result.append(program)

            if len(result) <= 0:
                self.log('Error while parsing service %s, returned data is: %s' % (self.serviceName, str(httpdata)))
                self.noPremiumMessage()

        except:
            self.log('getChannelList exception: %s' % getExceptionString())
        return result

    def getChannelStream(self, chann):
        data = None
        try:
            #url = self.url + 'v1/channel/%s?format_id=2&device_type=web' % chann.cid
            #data = self.sl.getJsonFromExtendedAPI(url, cookieFile = COOKIE_FILE, load_cookie = True, jsonLoadsResult=True, skipSslCertificate=True, customHeaders=headers)

            url = self.url + 'v1/channel/%s' % chann.cid
            data = {'format_id': '2', 'device': 'm_web'}
            data = requests.get(url, params=data, verify=False, headers=headers).json()
            
            if data is None: # or data['status'] != 'ok'
                self.log('Error getting channel stream, result: %s' % str(data))
                return None

            stream_list = list()
            streams1 = data['data']['stream_channel']['streams']
            for streams2 in streams1:
                for streams3 in streams2['url']:
                    if 'playlist.m3u8' in streams3:
                        self.log('Adding stream: %s' % streams3)
                        stream_list.append(streams3 + self.cookie_postfix)

            if len(stream_list) > 0:
                random_index = randrange(0, len(stream_list))
                data = stream_list[random_index]

            if data is not None and data != "":
                chann.strm = data
                self.log('getChannelStream found matching channel: cid: %s, name: %s, rtmp: %s' % (chann.cid, chann.name, chann.strm))
                return chann
            else:
                self.log('getChannelStream error getting channel stream2, result: %s' % str(data))
                return None
        except Exception, e:
            self.log('getChannelStream exception while looping: %s\n Data: %s' % (getExceptionString(), str(data)))
        return None
