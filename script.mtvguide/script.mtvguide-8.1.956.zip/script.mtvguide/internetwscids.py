#      Copyright (C) 2019 Mariusz Brychcy
#
#      Some implementations are modified and taken from "plugin.video.internetws" - thank you very much mbebe!

import os, copy
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import xbmcvfs
import requests
import string
import cookielib
import internetwskb as kb
from strings import *
from serviceLib import *
from CommonFunctions import parseDOM 

serviceName         = 'Internetowa.ws'
internetwsUrl       = 'https://internetowa.tv/'
COOKIE_FILE = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')) , 'intws.cookie')
sess = requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIE_FILE)

class InternetwsUpdater(baseServiceUpdater):
    def __init__(self):
        self.serviceName        = serviceName
        self.localMapFile       = 'internetwsmap.xml'
        baseServiceUpdater.__init__(self)
        self.serviceEnabled     = ADDON.getSetting('internetws_enabled')
        self.login              = ADDON.getSetting('internetws_username').strip()
        self.password           = ADDON.getSetting('internetws_password').strip()
        self.servicePriority    = int(ADDON.getSetting('priority_internetws'))
        self.url                = internetwsUrl
        self.addDuplicatesToList = True

    def loginService(self):
        try:       
            username = self.login
            password = self.password 
            lastl = ADDON.getSetting('lastl')
            lastp = ADDON.getSetting('lastp')
            
            if username and password:
                sess.headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/66.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    'Referer': 'https://internetowa.tv/logowanie/',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',}  
                if lastl == username and lastp == password:
                    if os.path.isfile(COOKIE_FILE):
                        sess.cookies.load() 
                else:
                    sess.cookies.clear()    
                html = sess.get('https://internetowa.tv/logowanie/', headers=sess.headers,cookies=sess.cookies)#.content
                captcha = re.search('https://internetowa.tv/captcha/', html.content)
                
                if captcha:
                    headers = {
                        'Host': 'internetowa.tv',
                        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/66.0',
                        'accept': 'image/webp,*/*',
                        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                        'referer': 'https://internetowa.tv/logowanie/',
                        'dnt': '1',
                        'te': 'trailers',
                    }
                    
                    response = sess.get('https://internetowa.tv/captcha/', cookies=html.cookies, headers=headers, verify=False)
                    
                    search_term = kb.Keyboard(response.content)

                    data = {'email': username,'password': password,'captcha':search_term}
                else:
                    data = {'email': username,'password': password}
                response = sess.post('https://internetowa.tv/logowanie/#', headers=sess.headers, data=data, allow_redirects=False) 

                if response.cookies.get('login') is not None:
                    sess.cookies.save() 
                    ADDON.setSetting("lastl", username)
                    ADDON.setSetting("lastp", password)
                #if os.path.isfile(COOKIE_FILE):
                    sess.cookies.load()     
                #sess.cookies.load()    
                html = sess.get('https://internetowa.tv/konto/',cookies=sess.cookies).content

                premium = re.findall('Konto premium, wa.+?ne do (.+?). Masz', html)
                free = re.findall('Brak konta premium', html)
                
                if premium:
                    info = premium[0]                          
                    return True
                elif free:
                    self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                    self.noPremiumMessage()
                    sess.cookies.clear()
                    sess.cookies.save() 
                    return False
                else:
                    self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                    self.loginErrorMessage()
                    sess.cookies.clear()
                    sess.cookies.save() 
                    return False              
            else:
                self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                self.loginErrorMessage()
                sess.cookies.clear()
                sess.cookies.save()  
                return False 

        except:
            self.log('Exception while trying to log in: %s' % getExceptionString())
            self.loginErrorMessage()
        return False

    def getChannelList(self, silent):
        result = list()

        if not self.loginService():
            return result

        self.log('\n\n')
        self.log('[UPD] Pobieram liste dostepnych kanalow %s z %s' % (self.serviceName, self.url))
        self.log('[UPD] -------------------------------------------------------------------------------------')
        self.log('[UPD] %-10s %-35s %-15s %-20s %-35s' % ( '-CID-', '-NAME-', '-GEOBLOCK-', '-ACCESS STATUS-', '-IMG-'))
        
        try:
            sess.cookies.load() 
            html = sess.get('https://internetowa.tv/', cookies=sess.cookies).text        
            parse_result = parseDOM(html,'div', attrs={'id': "allhome"})[0] 

            items = parseDOM(parse_result,'div', attrs={'class': "channelb"})#[0] 

            html = sess.get('https://internetowa.tv/program-tv/').content
            parse_result = parseDOM(html,'div', attrs={'id': "epgBig"})[0] 
            subset = parseDOM(result,'tr')        
            for item in items:
                cid = parseDOM(item, 'a', ret='href')[0]
                img = parseDOM(item, 'img', ret='src')[0]
                name = parseDOM(item, 'a', ret='title')[0]     

                program = TvCid(cid, name, name, img=img)
                result.append(program)


            if len(result) <= 0:
                self.log('Error while parsing service %s, returned data is: %s' % (self.serviceName, str(html)))
                self.noPremiumMessage()

        except:
            self.log('getChannelList exception: %s' % getExceptionString())
        return result

    def getChannelStream(self, chann):
        data = None
        stream_url = chann.cid
        exlink = 'Test'
        if 'm3u8' in exlink:
            stream_url = exlink
        else:
            try:
                if os.path.isfile(COOKIE_FILE):
                    sess.cookies.load() 
                html = sess.get(stream_url).content
                deb('HTML: %s' % html)
                iframe = parseDOM(html, 'iframe', ret='src')[0]
                sess.headers.update({'Referer': stream_url})
                html = (sess.get(iframe).content).replace("\'",'"')
                if 'js/hls.js' in html:
                    stream_u = re.findall("""hls.loadSource\(['"](.+?)['"]\)""", html)[0]
                else:
                    stream_u = re.findall('src="(.+?m3u8.+?)"', html)[0]
                stream_url = stream_u + '|Referer=' + iframe 

                data = stream_url

                if data is not None and data != "":
                    chann.strm = data
                    self.log('getChannelStream found matching channel: cid: %s, name: %s, rtmp: %s' % (chann.cid, chann.name, chann.strm))
                    return chann
                else:
                    self.log('getChannelStream error getting channel stream2, result: %s' % str(data))
                    return None
            except Exception, e:
                self.log('getChannelStream exception while looping: %s\n Data: %s' % (getExceptionString(), str(data)))
            return None
        

